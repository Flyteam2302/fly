module.exports = {
  token: "",
  ticketChannel: "1117368744876965970",
  ticketRoles: ["1117368552610086942"],
  ticketCategory: "1117368619014299698",
  guildId: "1116427643928195262",
};
